// coding: utf-8
// All three following symbols should highlight as keywords
cheese
käse
сыр

// Lookalikes with ASCII so should not highlight:
сыp
cыp
