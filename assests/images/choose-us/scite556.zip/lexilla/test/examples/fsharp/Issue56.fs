// not folded

// first line in comment fold
// second . . .
// third . . .
namespace Issue56

open System

module LineBasedFoldingCheck =
    open FSharp.Quotations
    open FSharp.Reflection

    () |> ignore
